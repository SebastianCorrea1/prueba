<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>HOLA</title>
        <!-- <link rel="stylesheet" href="<?php echo e(asset('css/export.css')); ?>"> -->

        <!-- Fonts -->
        <!-- <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet"> -->

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            .table-bordered td {
                align="center";
            }
        </style>
    </head>
    <body>
        <h2><center>PRODUCTOS REGISTRADOS EN EL SISTEMAS</center></h2>

        <form action="<?php echo e(route('createProduct')); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <input type="submit"  class="btn btn-lg btn-primary btn-block btn-signin" value="Crear Producto">
        </form>
        <br>

        <form action="<?php echo e(route('sellProduct')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <select  name="product_id" class="form-control" required>
                <option value="">Seleccione...</option>
                <?php $__currentLoopData = $record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $records): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($records->id); ?>"><?php echo e($records->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="number" min="1" pattern="^[0-9]+" name="amountToSell" placeholder="Cantidad a Vender" class="form-control mb-2" required>
            <input type="submit"  class="btn btn-lg btn-primary btn-block btn-signin" value="Vender Producto">
        </form>
        <br>
        <table border="1" ALIGN="center">
                <tr>
                    <td>NOMBRE PRODUCTO</td>
                    <td>REFERENCIA PRODUCTO</td>
                    <td>PRECIO PRODUCTO</td>
                    <td>PESO PRODUCTO</td>
                    <td>CATEGORIA PRODUCTO</td>
                    <td>STOCK PRODUCTO</td>
                    <td>ACCIONES</td>
                </tr>
        <?php $__currentLoopData = $record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $records): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                <tr>
                    <td><?php echo e($records->name); ?></td>
                    <td><?php echo e($records->reference); ?></td>
                    <td><?php echo e($records->price); ?></td>
                    <td><?php echo e($records->weight); ?></td>
                    <td><?php echo e($records->category); ?></td>
                    <td><?php echo e($records->stock); ?></td>
                    <td>
                        <form action="<?php echo e(route('editProducts', ['id' => $records->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-primary btn-block" type="sumit">Edit</button>
                        </form>
                        <form action="<?php echo e(route('removeProducts', ['id' => $records->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-primary btn-block" type="sumit">Remove</button>
                        </form>
                    </td>
                </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </body>
</html>
<?php /**PATH C:\Users\Sebastian\Desktop\cafeteria\resources\views/init.blade.php ENDPATH**/ ?>