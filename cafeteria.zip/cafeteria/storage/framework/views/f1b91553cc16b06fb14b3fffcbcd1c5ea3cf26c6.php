<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>HOLA</title>
        <!-- <link rel="stylesheet" href="<?php echo e(asset('css/export.css')); ?>"> -->

        <!-- Fonts -->
        <!-- <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet"> -->

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            .table-bordered td {
                align="center";
            }
        </style>
    </head>
    <body>
        <h2><center>PRODUCTOS REGISTRADOS EN EL SISTEMAS</center></h2>

        <form action="<?php echo e(route('init')); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <!-- <input type="text" name="nombre" placeholder="nombre del producto" class="form-control mb-2"> -->
            <input type="submit"  class="btn btn-lg btn-primary btn-block btn-signin" value="Listar Productos">
            <!-- <input type="submit"  class="btn btn-lg btn-primary btn-block btn-signin" value="Editar Producto">
            <input type="submit"  class="btn btn-lg btn-primary btn-block btn-signin" value="Eliminar Producto"> -->
        </form>
        <br>
        <!-- <a type="submit" href="<?php echo e('init'); ?>" class="btn btn-lg btn-primary btn-block btn-signin" style="text-align:right">Procesar</a> -->
        <table border="1" ALIGN="center">
                <tr>
                    <td>NOMBRE PRODUCTO</td>
                    <td>REFERENCIA PRODUCTO</td>
                    <td>PRECIO PRODUCTO</td>
                    <td>PESO PRODUCTO</td>
                    <td>CATEGORIA PRODUCTO</td>
                    <td>STOCK PRODUCTO</td>
                    
                </tr>
                <form action="<?php echo e(route('saveEditProducts', ['id' => $record->id])); ?>" method="POST">
                    <tr>
                        <?php echo csrf_field(); ?>
                        <td><input type="text" name="name" placeholder="Nombre del Producto" class="form-control mb-2" value="<?php echo e($record->name); ?>" required></td>
                        <td><input type="text" name="reference" placeholder="Referencia del Producto" class="form-control mb-2" value="<?php echo e($record->reference); ?>" required></td>
                        <td><input type="number" min="1" pattern="^[0-9]+" name="price" placeholder="Precio del Producto" class="form-control mb-2" value="<?php echo e($record->price); ?>" required></td>
                        <td><input type="number" name="weight" min="1" pattern="^[0-9]+" placeholder="Peso del Producto" class="form-control mb-2" value="<?php echo e($record->weight); ?>" required></td>
                        <td><input type="text" name="category" placeholder="Categoria del Producto" class="form-control mb-2" value="<?php echo e($record->category); ?>" required></td>
                        <td><input type="number" name="stock" min="0" pattern="^[0-9]+" placeholder="Stock del Producto" class="form-control mb-2" value="<?php echo e($record->stock); ?>" required></td>
                        <td><button class="btn btn-primary btn-block" type="sumit">Save</button>
                    </tr>
                </form>
        </table>
        <!-- <nav>
            <ul>
                <li><a href ="/">welcome</a></li>
            </ul>


        </nav> -->
        <!-- <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    Laravel
                </div>

                <div class="links">
                    <a href="https://laravel.com/docs">Docs</a>
                    <a href="https://laracasts.com">Laracasts</a>
                    <a href="https://laravel-news.com">News</a>
                    <a href="https://blog.laravel.com">Blog</a>
                    <a href="https://nova.laravel.com">Nova</a>
                    <a href="https://forge.laravel.com">Forge</a>
                    <a href="https://vapor.laravel.com">Vapor</a>
                    <a href="https://github.com/laravel/laravel">GitHub</a>
                </div>
            </div>
        </div> -->
    </body>
</html>
<?php /**PATH C:\Users\Sebastian\Desktop\cafeteria\resources\views/editProduct.blade.php ENDPATH**/ ?>