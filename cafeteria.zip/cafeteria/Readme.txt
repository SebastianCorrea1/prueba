Version 7.2 de Laravel

Mysql version 8.0

correr comando php artisan serve

base de datos sin contraseña
